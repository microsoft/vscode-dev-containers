package net.azib.ipscan.gui.feeders;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class ControlsArea extends Composite {
	public ControlsArea(Shell parent) {
		super(parent, SWT.NONE);
	}

	@Override protected void checkSubclass() {}
}
