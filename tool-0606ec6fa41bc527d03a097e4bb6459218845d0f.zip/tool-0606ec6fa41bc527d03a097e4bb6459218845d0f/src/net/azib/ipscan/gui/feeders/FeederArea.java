package net.azib.ipscan.gui.feeders;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class FeederArea extends Composite {
	public FeederArea(Shell parent) {
		super(parent, SWT.NONE);
	}

	@Override protected void checkSubclass() {}
}
