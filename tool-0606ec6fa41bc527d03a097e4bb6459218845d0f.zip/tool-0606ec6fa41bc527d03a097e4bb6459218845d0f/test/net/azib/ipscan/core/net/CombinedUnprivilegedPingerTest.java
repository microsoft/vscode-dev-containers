package net.azib.ipscan.core.net;

public class CombinedUnprivilegedPingerTest extends AbstractPingerTest {
	public CombinedUnprivilegedPingerTest() throws Exception {
		super(CombinedUnprivilegedPinger.class);
	}
}
