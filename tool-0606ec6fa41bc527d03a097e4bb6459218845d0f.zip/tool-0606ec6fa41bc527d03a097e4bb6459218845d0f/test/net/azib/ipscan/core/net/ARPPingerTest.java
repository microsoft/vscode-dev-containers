package net.azib.ipscan.core.net;

public class ARPPingerTest extends AbstractPingerTest {
	public ARPPingerTest() throws Exception {
		super(ARPPinger.class);
	}
}
