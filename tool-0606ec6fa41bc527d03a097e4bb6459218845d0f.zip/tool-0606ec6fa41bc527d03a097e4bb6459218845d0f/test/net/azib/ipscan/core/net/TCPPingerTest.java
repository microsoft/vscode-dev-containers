package net.azib.ipscan.core.net;

public class TCPPingerTest extends AbstractPingerTest {
	public TCPPingerTest() throws Exception {
		super(TCPPinger.class);
	}
}
