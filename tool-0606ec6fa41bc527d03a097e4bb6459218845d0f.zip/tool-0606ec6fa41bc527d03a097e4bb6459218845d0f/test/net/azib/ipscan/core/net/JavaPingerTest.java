package net.azib.ipscan.core.net;

public class JavaPingerTest extends AbstractPingerTest {
	public JavaPingerTest() throws Exception {
		super(JavaPinger.class);
	}
}
