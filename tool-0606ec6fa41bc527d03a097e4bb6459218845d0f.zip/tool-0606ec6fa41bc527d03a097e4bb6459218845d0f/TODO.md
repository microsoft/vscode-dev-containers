* SWT Error: no more handles (empty modal window appears)
* Retrieve value for any fetcher from context menu
* Monitoring mode (which IPs appear/disappear)
* UX: button for netmask application?
* Graalvm native-image to build binary

* Use ServiceLoader for plugins
* Use ipify for /iplocate
* Add URLFetcher with configurable URL and JSON/XPath expression
* WHOIS fetcher

* Windows: net stop SharedAccess
* gtk sort direction arrows
* advanced exporting options dialog (with append checkbox)
* Enable/Disable ports (without resetting)
* Opener Launchers to the details window
* multiple port support web-detect, opening in browser selects scanned ports if available
* add new fetchers by configuration of PortTextFetcher
* public XSL for XMLExporter
* Easier adding/removing of columns to the result table (without resetting the results)
* command-line: support favorites
* command-line: add netmask support to the range feeder 
* find not-null for column
* export/import of settings (profiles or tie with Favorites?)
* display friendly names of ports
* preferences profiles (tied to favorites?)
* free text (advanced) feeder
* saving and restoring of results together with all options
* advanced find (firefox-like) with options Find Next, Find Previoius, Select all matches
* count occurencies of search (either separate or included)
* diff with saved
* show distinct values for a column
* SWT bug: deleting of many IPs at once is very slow (freezes the ipscan) due to the sorting of provided indices

* use jpcap for raw packet injection and ARP scanning
* startup as root option
* compile librocksaw for mac and linux64
